from django.apps import AppConfig


class TheatreConfig(AppConfig):
    name = 'theatre'
