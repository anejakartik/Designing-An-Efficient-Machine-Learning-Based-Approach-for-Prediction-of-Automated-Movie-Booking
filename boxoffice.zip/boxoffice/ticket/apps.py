from django.apps import AppConfig


class TicketConfig(AppConfig):
    name = 'ticket'
