from django.contrib import admin
from .models import Contact_Us
# Register your models here.


class Contact_UsAdmin(admin.ModelAdmin):
    list_display = ("contact_id","contact_name","contact_email","contact_subject","contact_resolved","created_at","updated_at")
    search_fields = ('contact_id','contact_name','contact_email')
    list_filter = ('contact_resolved',)
    empty_value_display = '-empty-'

admin.site.register(Contact_Us,Contact_UsAdmin)
