from django.db import models

# Create your models here.
from django.contrib.auth.models import Group, User

class CustomerManager(models.Manager):
    """
    Lets us do querysets limited to families that have
    currently enrolled students, e.g.:
        Family.has_students.all()
    """
    def get_query_set(self):
        return super(User, self).get_query_set().filter(is_superuser=False).distinct()


class Customer(Group):

    # Two managers for this model - the first is default
    # (so all families appear in the admin).
    # The second is only invoked when we call
    # Family.has_students.all()
    objects = models.Manager()
    customers = CustomerManager()

    class Meta:
        verbose_name_plural = "Customers"
        ordering = ['name']

    def __unicode__(self):
        return self.username
