# django-movie-booking:-

project to book movie tickets with machine learning


working with user functions